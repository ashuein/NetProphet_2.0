#ifndef GLAM2_RECODE3_30COMP_H
#define GLAM2_RECODE3_30COMP_H

#include "glam2_dirichlet.h"

void dmix_recode3(dirichlet_mix *m);

#endif
