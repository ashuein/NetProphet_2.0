#use ExtUtils::testlib;
require "./Hypergeom.pm";

#print Hypergeom::cumhyper(483,454,394,3017);
print Hypergeom::cumbino(30,100,0.19);
print "\n";
